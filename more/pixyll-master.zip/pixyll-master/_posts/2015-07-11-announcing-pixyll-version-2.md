---
layout:     post
title:      Announcing Version 2.0
date:       2015-07-11
summary:    Now, Pixyll is lighter weight and more customizable than before.
categories: jekyll pixyll
---

In an effort to make Pixyll easier to customize and more aesthetically pleasing, we've released version `2.0`.

Pixyll now features:

* Line anchors in code blocks and new syntax highlighting
* A customizable variables file
* Modular, and lighter weight CSS
* No more `max-width` media queries
