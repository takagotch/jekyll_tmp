# estivo
Estivo is a blogging theme for Jekyll that I created for my personal use, until I changed my mind, oh designers...
It runs on jekyll v.2.5.3 and supports SASS out of the box. The code is messy and hacked together, definitely not something you'd want to show to the public, the SASS code is also just CSS, but it's there if you want to hack it away. A little snippet is also visible on my [dribbble page](http://drbl.in/nyKl)

It's open sourced under the MIT license and can be download from the GitHub project.

### Usage

`
jekyll s --host=0.0.0.0
`

### Support

I don't provide support, and I don't intend on updating it at all, but feel free to fork it, and make something awesome out of it.

### License

Released under MIT by [@fffabs](http://twitter.com/fffabs)
