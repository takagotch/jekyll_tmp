$(".full img").on("click", function() {
  $(this).toggleClass("zoom");
});