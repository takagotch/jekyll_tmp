---
layout: post
title: "Sample Link Post"
description: "Example and code for using link posts."
category: Sample-Posts
tags: [sample post, link post]
comments: true
link: http://alum.mit.edu/www/hmfaysal
---

HMFAYSAL OMEGA Theme now supports **link posts**, made famous by John Gruber. To activate just add `link: http://url-you-want-linked` to the post's YAML front matter and you're done.