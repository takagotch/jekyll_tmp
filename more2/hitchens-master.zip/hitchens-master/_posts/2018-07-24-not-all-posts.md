---
title: ""
layout: post
author: "Pat Dryburgh"
categories: opinion
---

Not all posts need a title.

<!-- excerpt_separator -->

They sometimes just want to be left alone.