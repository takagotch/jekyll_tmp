---
layout: categories
title: Categories
permalink: /categories
---