---
name: Betty Jefferson
position: Developer
image_path: https://source.unsplash.com/collection/139386/601x601?a=.png
twitter_username: CloudCannon
blurb: Betty is a bookworm who will typically have four books on the go.
---
