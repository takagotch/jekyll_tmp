---
layout: postcn
title: "“JOYTOU博客”微信公众号开通啦"
description: "“JOYTOU博客”公众号开通"
date: 2017-12-06 03:02:00 +0800
lang: cn
nav: post
stickie: false
category: official
tags: [wechat, joytou]
---

* content
{:toc}


<p>在这里，你可以随时的关注到本博客的最新动态。不用再每天刷着博客，等待又等待。</p>
<p>手指轻轻一点，即可了解博客的最新信息、访问博客。只要有任何关于本博客的消息，我们都将第一时间发送给您！</p>
<p>用户可通过搜索“<b>JOYTOU博客</b>”或“<b>joytouBlog</b>”，或者直接扫描下方二维码关注！</p>
<img src="{{ '/assets/qrcode_for_gh_fdcd74bd5633_1280.jpg' | prepend: site.baseurl }}" class="img-responsive"/>
