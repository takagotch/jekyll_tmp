---
layout: post
category : lessons
tagline: "Using FullIt.github.io"
tags : [bootstrap, web desing, jekyll]
img : 
img-mobile : 
img2 : 
img3 : 
author : Antonio Trento
title2 : Improve the desing of your blog
title3 : Make it a full of slides
css: 
js: 
bgcolor: ff5a71
keywords: fullit, web desing, css, html, bootstrap
canonical: https://fullit.github.io
---
{% include JB/setup %}

## How you can make an Amazing Website?

Jekyll can give you the possibility to make awesome websites in minutes that are **more faster than major other sites in the world**

Use this template to generate a great jekyll website via a full of slide system make by fullpage.js and build quick your pages using the last version of Bootstrap 4.

