---
layout: collection
title: "Recipes"
collection: recipes
permalink: /recipes-archive/
author_profile: false
---

Sample document listing for the collection `_recipes`.