---
layout: post
title: "Test external url"
permalink: test-external-url
date: 2015-11-16 15:51:23
comments: true
external_url: http://nandomoreira.me/
description: "Test external-url"
keywords: "test, external, url"
category: jekyll
tags:
- text
- jekyll
- external-url
---
