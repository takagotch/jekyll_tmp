# Windows 95 Theme for Jekyll

![ss](https://github.com/h01000110/windows-95/raw/gh-pages/screenshot_2.png)

Homepage: [Windows 95](https://h01000110.github.io/20170917/windows-95)

Demo: [Click here](https://h01000110.github.io/windows-95/)

Author: [h01000110 (hi)](https://github.com/h01000110)

License: [MIT](https://github.com/h01000110/windows-95/blob/master/LICENSE)
