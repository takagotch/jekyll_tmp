---
title: 'Mikes Auto Parts'
image: ''
businessurl: ''
name: 'Tony Smith'
business: 'Local Business Name'
jobtitle: 'Owner'
---

> Value proposition accelerator crowdsource channels customer. Research & development seed money channels creative. Ramen buzz ecosystem technology equity paradigm shift business-to-business lean startup social proof client startup. Agile development partnership business-to-consumer pitch marketing twitter venture advisor metrics alpha bootstrapping infrastructure seed round.
