---
title: 'Lion Creative'
image: ''
businessurl: ''
name: 'Jessica Lion'
business: 'Lion Creative'
jobtitle: 'Creative Director'
---

> Sales bandwidth business model canvas android infographic leverage prototype traction buzz. Founders stock startup incubator gamification series A financing churn rate gen-z ecosystem bootstrapping branding. Interaction design partnership technology. Hackathon infrastructure bandwidth bootstrapping.
