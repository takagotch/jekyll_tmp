---
layout: "git-wiki-bs-united"
---

# Theme: United


This is an example of layout built using [bootstrap united theme](https://bootswatch.com/united/)


To use it as your default theme you've to change layout configuration in your _config.yml, for example:

```
defaults:
 -
    scope:
      path: ""
    values:
      layout: "git-wiki-bs-united"
 -
    scope:
      path: ""
      type: "pages"
    values:
      layout: "git-wiki-bs-united"
```

