# git-wiki

Demo and documentation for git-wiki-theme: https://github.com/Drassil/git-wiki-theme
