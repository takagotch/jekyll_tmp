---
layout: "writing_by_category"
category: "cat03"
permalink: "/writing/category/cat03/"
header-img: "assets/owner/hero/archive-bg.jpg"
---