---
layout: home
permalink: /
title: "Your Awesome Site"
excerpt: "A Coming Soon Template"
---
# Website is coming soon
Tell the users that your website is not active yet. Put the reason to subscribe for the notification in this paragraph. Tell them about their problems which you would like to solve. Don’t forget the final call to action.
