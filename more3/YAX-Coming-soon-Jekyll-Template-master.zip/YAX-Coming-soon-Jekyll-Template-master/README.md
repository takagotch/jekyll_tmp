# YAX-Coming-soon-Jekyll-Template
Free Bootstrap HTML5 CSS3 Responsive Coming soon  Jekyll template

Designed by : Ilya B.  
url: https://www.behance.net/gallery/18421675/Free-Bootstrap-Psd-Coming-Soon-Template  

Converted PSD to HTML/CSS by:  
Morteza Aghili  
bio: http://mortezaaghili.github.io/  

Adpated to Jekyll by [yonojoy](https://github.com/yonojoy)

## Usage
Edit `index.md` to contain your message.

Edit `_config.yml` and add the following params:

* `countdown` to contain the target date in GMT/UTC
* `owner` to contain infos about the site owner.

That's it.

## Installation

Requires [Jekyll](http://jekyllrb.com/) 3+. 

If you are creating a new Jekyll site using Skinny Bones following these steps:

1. Download and unzip.
2. Run `bundle install` to install all dependencies 
3. Update `_config.yml` and `index.md` as described above.

