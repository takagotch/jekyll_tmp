---
name: Betty Jefferson
position: Developer
image_path: https://source.unsplash.com/collection/139386/602x602?a=.png
twitter: CloudCannonApp
blurb: Betty is a bookworm who will typically have four books on the go.
---
