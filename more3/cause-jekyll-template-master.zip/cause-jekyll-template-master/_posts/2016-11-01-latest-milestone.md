---
title: We've raised $2000!
author_staff_member: wooly-mcbaa
date: 2016-11-01
featured_image: https://unsplash.it/570/400?image=1080
---
Thank you do everyone who has made contributions. This money is going towards reaching sheep in paddocks far and wide. The revolution has begun.
